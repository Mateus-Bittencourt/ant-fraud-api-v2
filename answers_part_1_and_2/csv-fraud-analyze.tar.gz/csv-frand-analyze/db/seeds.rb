# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: "Star Wars" }, { name: "Lord of the Rings" }])
#   Character.create(name: "Luke", movie: movies.first)

require 'csv'
# require "securerandom"

csv_file =  'csv/transactional-sample.csv'

CSV.foreach(csv_file, headers: :first_row, header_converters: :symbol) do |row|
  has_cbk = row[:has_cbk] == 'TRUE'
  Transaction.create(
    transaction_id: row[:transaction_id].to_i,
    merchant_id: row[:merchant_id].to_i,
    user_id: row[:user_id].to_i,
    card_number: row[:card_number],
    transaction_date: row[:transaction_date],
    transaction_amount: row[:transaction_amount].to_f,
    device_id: row[:device_id].to_i,
    has_cbk:
  )
end
